<?php
/**
 * Plugin Name: SBOM Weather Connector
 * Plugin URI: https://sbom-weather.com
 * Description: Lightweight, secure connector plugin for WordPress to collect and sync core, PHP runtime, plugin (active & inactive), and theme SBOM manifest data. Supports 12-hour WP-Cron hash-diff sync and optional REST API pull endpoint.
 * Version: 1.1.0
 * Author: SBOM Weather Team
 * Author URI: https://sbom-weather.com
 * License: GPLv2 or later
 * Text Domain: sbom-weather-connector
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SBOM_WEATHER_VERSION', '1.1.0');
define('SBOM_WEATHER_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SBOM_WEATHER_PLUGIN_URL', plugin_dir_url(__FILE__));

class SBOM_Weather_Connector {

    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Load i18n text domain
        add_action('init', array($this, 'load_textdomain'));

        // Activation & Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Admin menu & settings
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));

        // REST API endpoint registration (Optional Pull support)
        add_action('rest_api_init', array($this, 'register_rest_routes'));

        // Cron event hook (12-hour interval: twicedaily)
        add_action('sbom_weather_cron_sync', array($this, 'handle_cron_sync'));

        // Manual sync AJAX action
        add_action('wp_ajax_sbom_weather_manual_sync', array($this, 'ajax_manual_sync'));
    }

    /**
     * Load plugin textdomain for translations (l10n/i18n)
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'sbom-weather-connector',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages'
        );
    }

    /**
     * Plugin activation: schedule 12-hour (twicedaily) cron
     */
    public function activate() {
        $timestamp = wp_next_scheduled('sbom_weather_cron_sync');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'sbom_weather_cron_sync');
        }
        wp_schedule_event(time(), 'twicedaily', 'sbom_weather_cron_sync');
    }

    /**
     * Plugin deactivation: clear scheduled cron
     */
    public function deactivate() {
        $timestamp = wp_next_scheduled('sbom_weather_cron_sync');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'sbom_weather_cron_sync');
        }
    }

    /**
     * Register Admin Menu under Settings
     */
    public function add_admin_menu() {
        add_options_page(
            __('SBOM Weather Settings', 'sbom-weather-connector'),
            'SBOM Weather',
            'manage_options',
            'sbom-weather',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Get default Site ID derived from site domain
     */
    public function get_default_site_id() {
        $host = parse_url(get_site_url(), PHP_URL_HOST);
        if (empty($host)) {
            $host = 'wordpress';
        }
        $clean_host = preg_replace('/[^a-zA-Z0-9]/', '_', strtolower($host));
        return 'site_' . trim($clean_host, '_');
    }

    /**
     * Get effective Site ID (auto-generates and saves if empty)
     */
    public function get_effective_site_id() {
        $site_id = trim((string) get_option('sbom_weather_site_id', ''));
        if (empty($site_id)) {
            $site_id = $this->get_default_site_id();
            update_option('sbom_weather_site_id', $site_id);
        }
        return $site_id;
    }

    /**
     * Get effective API URL (defaults to http://localhost:8787/api/v1/sync on .local / localhost environments)
     */
    public function get_effective_api_url() {
        $host = (string) parse_url(get_site_url(), PHP_URL_HOST);
        $is_local = (strpos($host, '.local') !== false || $host === 'localhost' || $host === '127.0.0.1');
        $default_url = $is_local ? 'http://localhost:8787/api/v1/sync' : 'https://sbom-weather-backend.mahorobalab.workers.dev/api/v1/sync';

        $saved_url = trim((string) get_option('sbom_weather_api_url', ''));
        if (empty($saved_url) || ($is_local && $saved_url === 'https://api.sbom-weather.com/api/v1/sync')) {
            update_option('sbom_weather_api_url', $default_url);
            return $default_url;
        }
        if (!empty($saved_url) && !preg_match('#/api/v1/sync/?$#i', $saved_url)) {
            $saved_url = rtrim($saved_url, '/') . '/api/v1/sync';
        }
        return $saved_url;
    }

    /**
     * Sanitize API URL option (ensures trailing /api/v1/sync path)
     */
    public function sanitize_api_url($url) {
        $clean = esc_url_raw(trim((string)$url));
        if (!empty($clean) && !preg_match('#/api/v1/sync/?$#i', $clean)) {
            $clean = rtrim($clean, '/') . '/api/v1/sync';
        }
        return $clean;
    }

    /**
     * Register settings in WordPress Options API
     */
    public function register_settings() {
        register_setting('sbom_weather_settings_group', 'sbom_weather_api_url', array(
            'type' => 'string',
            'sanitize_callback' => array($this, 'sanitize_api_url'),
            'default' => $this->get_effective_api_url()
        ));

        register_setting('sbom_weather_settings_group', 'sbom_weather_api_token', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        register_setting('sbom_weather_settings_group', 'sbom_weather_site_id', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => $this->get_default_site_id()
        ));

        register_setting('sbom_weather_settings_group', 'sbom_weather_endpoint_token', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ));

        register_setting('sbom_weather_settings_group', 'sbom_weather_enable_cron', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true
        ));

        register_setting('sbom_weather_settings_group', 'sbom_weather_enable_pull', array(
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ));
    }

    /**
     * Collect WordPress manifest (Core, PHP Runtime, Active & Inactive Plugins, Themes)
     */
    public function collect_manifest() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // 1. Core Version
        global $wp_version;
        $core_version = !empty($wp_version) ? $wp_version : get_bloginfo('version');

        // 2. Installed Plugins (Both Active and Inactive)
        $all_plugins = get_plugins();
        $plugin_items = array();

        foreach ($all_plugins as $plugin_file => $plugin_data) {
            $is_active = is_plugin_active($plugin_file);
            $slug = dirname($plugin_file);
            if ($slug === '.' || empty($slug)) {
                $slug = basename($plugin_file, '.php');
            }

            $plugin_items[] = array(
                'name' => $slug,
                'title' => $plugin_data['Name'],
                'version' => $plugin_data['Version'],
                'active' => (bool) $is_active,
                'file' => $plugin_file,
                'author' => wp_strip_all_tags($plugin_data['Author']),
            );
        }

        // 3. Current Theme & Parent Theme
        $theme = wp_get_theme();
        $theme_data = array(
            'name' => $theme->get_stylesheet(),
            'title' => $theme->get('Name'),
            'version' => $theme->get('Version'),
            'is_child' => is_child_theme(),
        );

        $parent_theme_data = null;
        if (is_child_theme() && $theme->parent()) {
            $parent = $theme->parent();
            $parent_theme_data = array(
                'name' => $parent->get_template(),
                'title' => $parent->get('Name'),
                'version' => $parent->get('Version'),
            );
        }

        // 4. PHP Environment info
        $php_version = phpversion();

        return array(
            'format' => 'sbom-weather-wordpress-manifest',
            'version' => '1.1',
            'site_url' => get_site_url(),
            'site_id' => $this->get_effective_site_id(),
            'generated_at' => gmdate('Y-m-d\TH:i:s\Z'),
            'environment' => array(
                'php_version' => $php_version,
                'wp_version' => $core_version,
                'server_software' => isset($_SERVER['SERVER_SOFTWARE']) ? sanitize_text_field(wp_unslash($_SERVER['SERVER_SOFTWARE'])) : '',
            ),
            'wordpress' => array(
                'version' => $core_version,
            ),
            'theme' => $theme_data,
            'parent_theme' => $parent_theme_data,
            'plugins' => $plugin_items,
            'stats' => array(
                'total_plugins' => count($plugin_items),
                'active_plugins' => count(array_filter($plugin_items, function($p) { return $p['active']; })),
                'inactive_plugins' => count(array_filter($plugin_items, function($p) { return !$p['active']; })),
            )
        );
    }

    /**
     * Compute deterministic SHA-256 hash of normalized packages (matches Cloudflare Worker computeManifestHash)
     */
    public function compute_manifest_hash($packages) {
        $canonical = array();
        foreach ($packages as $p) {
            $clean_ver = preg_replace('/^[vV]/', '', trim((string) $p['version']));
            $canonical[] = array(
                'ecosystem' => $p['ecosystem'],
                'name' => $p['name'],
                'version' => $clean_ver,
                'active' => !empty($p['active']) ? 1 : 0,
            );
        }

        usort($canonical, function($a, $b) {
            $keyA = $a['ecosystem'] . ':' . $a['name'] . ':' . $a['version'];
            $keyB = $b['ecosystem'] . ':' . $b['name'] . ':' . $b['version'];
            return strcmp($keyA, $keyB);
        });

        return hash('sha256', wp_json_encode($canonical));
    }

    /**
     * Convert manifest to packages payload for Cloudflare Workers /api/v1/sync
     */
    public function format_sync_payload($force_refresh = false) {
        $manifest = $this->collect_manifest();
        $site_id = $this->get_effective_site_id();
        $enable_pull = get_option('sbom_weather_enable_pull', false);
        $endpoint_token = get_option('sbom_weather_endpoint_token', '');

        $packages = array();

        // 1. Add PHP Runtime (Language)
        if (!empty($manifest['environment']['php_version'])) {
            $packages[] = array(
                'name' => 'php',
                'version' => $manifest['environment']['php_version'],
                'ecosystem' => 'PHP',
                'componentType' => 'runtime',
                'active' => true,
            );
        }

        // 2. Add WordPress Core
        if (!empty($manifest['wordpress']['version'])) {
            $packages[] = array(
                'name' => 'wordpress',
                'version' => $manifest['wordpress']['version'],
                'ecosystem' => 'WordPress-Core',
                'componentType' => 'core',
                'active' => true,
            );
        }

        // 3. Add All Plugins (Active & Inactive)
        foreach ($manifest['plugins'] as $p) {
            $packages[] = array(
                'name' => $p['name'],
                'version' => $p['version'],
                'ecosystem' => 'WordPress',
                'componentType' => 'plugin',
                'active' => (bool) $p['active'],
            );
        }

        // 4. Add Theme & Parent Theme
        if (!empty($manifest['theme']['name'])) {
            $packages[] = array(
                'name' => $manifest['theme']['name'],
                'version' => $manifest['theme']['version'],
                'ecosystem' => 'WordPress-Theme',
                'componentType' => 'theme',
                'active' => true,
            );
        }
        if (!empty($manifest['parent_theme']['name'])) {
            $packages[] = array(
                'name' => $manifest['parent_theme']['name'],
                'version' => $manifest['parent_theme']['version'],
                'ecosystem' => 'WordPress-Theme',
                'componentType' => 'theme',
                'active' => true,
                'isDirect' => true,
            );
        }

        // Deterministic canonical sorting (ecosystem -> name -> version)
        foreach ($packages as &$pkg_ref) {
            if (!isset($pkg_ref['isDirect'])) {
                $pkg_ref['isDirect'] = true;
            }
        }
        unset($pkg_ref);

        usort($packages, function($a, $b) {
            $keyA = $a['ecosystem'] . ':' . $a['name'] . ':' . $a['version'];
            $keyB = $b['ecosystem'] . ':' . $b['name'] . ':' . $b['version'];
            return strcmp($keyA, $keyB);
        });

        $manifest_hash = $this->compute_manifest_hash($packages);

        $payload = array(
            'site_id' => $site_id,
            'manifest_hash' => $manifest_hash,
            'source' => 'wp_plugin',
            'ecosystem' => 'WordPress',
            'force_refresh' => (bool) $force_refresh,
            'manifest' => $manifest,
            'packages' => $packages,
            'timestamp' => gmdate('Y-m-d\TH:i:s\Z')
        );

        // Optional: Register Pull endpoint URL if enabled by the site admin
        if ($enable_pull && !empty($endpoint_token)) {
            $payload['pull_endpoint_url'] = get_rest_url(null, 'sbom-weather/v1/manifest');
            $payload['pull_endpoint_token'] = $endpoint_token;
        }

        return $payload;
    }

    /**
     * Send sync request to SBOM Weather Backend
     * - Step 1: Unless $force_refresh is true, check hash via GET /api/v1/sync?site_id=...&hash=...
     * - Step 2: If 200 OK (hash matched), update weather status immediately without sending full manifest.
     * - Step 3: If 409 Conflict (requires_manifest) or $force_refresh, POST full manifest.
     */
    public function execute_sync($force_refresh = false) {
        $api_url = $this->get_effective_api_url();
        $api_token = get_option('sbom_weather_api_token', '');
        $site_id = $this->get_effective_site_id();

        $payload = $this->format_sync_payload($force_refresh);
        $manifest_hash = $payload['manifest_hash'];

        $headers = array(
            'Accept' => 'application/json',
            'User-Agent' => 'SBOM-Weather-WordPress-Connector/' . SBOM_WEATHER_VERSION,
        );

        if (!empty($api_token)) {
            $headers['Authorization'] = 'Bearer ' . $api_token;
        }

        // Step 1: Lightweight GET Hash Check (when site_id is present and not forcing refresh)
        if (!$force_refresh && !empty($site_id)) {
            $check_url = add_query_arg(array(
                'site_id' => $site_id,
                'hash' => $manifest_hash,
            ), $api_url);

            $check_res = wp_remote_get($check_url, array(
                'headers' => $headers,
                'timeout' => 15,
                'sslverify' => false,
            ));

            if (!is_wp_error($check_res)) {
                $check_code = wp_remote_retrieve_response_code($check_res);
                $check_data = json_decode(wp_remote_retrieve_body($check_res), true);

                if ($check_code === 200 && empty($check_data['requires_manifest'])) {
                    $result_record = array(
                        'time' => current_time('mysql'),
                        'sync_mode' => 'GET (Hash Matched)',
                        'manifest_hash' => $manifest_hash,
                        'status_code' => $check_code,
                        'weather' => isset($check_data['weather']) ? $check_data['weather'] : 'sunny',
                        'pressure_hpa' => isset($check_data['pressureHpa']) ? $check_data['pressureHpa'] : 1013,
                        'days_neglected' => isset($check_data['daysNeglected']) ? $check_data['daysNeglected'] : 0,
                        'alerts_count' => isset($check_data['alerts']) ? count($check_data['alerts']) : 0,
                        'active_vuln_count' => isset($check_data['activeVulnCount']) ? $check_data['activeVulnCount'] : 0,
                        'inactive_vuln_count' => isset($check_data['inactiveVulnCount']) ? $check_data['inactiveVulnCount'] : 0,
                        'packages_count' => isset($check_data['packageCount']) ? $check_data['packageCount'] : count($payload['packages']),
                        'response' => $check_data
                    );
                    update_option('sbom_weather_last_sync_result', $result_record);

                    return array(
                        'success' => true,
                        'message' => __('Sync succeeded (No configuration changes: fetched latest weather via hash check).', 'sbom-weather-connector'),
                        'data' => $result_record
                    );
                }
            }
        }

        // Step 2: Full Manifest POST (when hash changed, first registration, or force_refresh)
        $headers['Content-Type'] = 'application/json';
        $json_body = wp_json_encode($payload);
        $post_body = $json_body;
        if (function_exists('gzencode')) {
            $compressed = gzencode($json_body, 6);
            if ($compressed !== false) {
                $post_body = $compressed;
                $headers['Content-Encoding'] = 'gzip';
            }
        }

        $response = wp_remote_post($api_url, array(
            'headers' => $headers,
            'body' => $post_body,
            'timeout' => 35,
            'sslverify' => false,
        ));

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => sprintf(__('Connection error: %s', 'sbom-weather-connector'), $response->get_error_message())
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body_raw = wp_remote_retrieve_body($response);
        $data = json_decode($body_raw, true);

        $result_record = array(
            'time' => current_time('mysql'),
            'sync_mode' => $force_refresh ? 'POST (Force Full Scan)' : 'POST (Manifest Updated)',
            'manifest_hash' => $manifest_hash,
            'status_code' => $status_code,
            'weather' => isset($data['weather']) ? $data['weather'] : 'unknown',
            'pressure_hpa' => isset($data['pressureHpa']) ? $data['pressureHpa'] : 1013,
            'days_neglected' => isset($data['daysNeglected']) ? $data['daysNeglected'] : 0,
            'alerts_count' => isset($data['alerts']) ? count($data['alerts']) : 0,
            'active_vuln_count' => isset($data['activeVulnCount']) ? $data['activeVulnCount'] : 0,
            'inactive_vuln_count' => isset($data['inactiveVulnCount']) ? $data['inactiveVulnCount'] : 0,
            'packages_count' => isset($data['packageCount']) ? $data['packageCount'] : count($payload['packages']),
            'response' => $data
        );

        update_option('sbom_weather_last_sync_result', $result_record);

        if ($status_code >= 200 && $status_code < 300) {
            return array(
                'success' => true,
                'message' => __('Sync succeeded.', 'sbom-weather-connector'),
                'data' => $result_record
            );
        }

        return array(
            'success' => false,
            'message' => sprintf(__('Server returned an error (%d).', 'sbom-weather-connector'), $status_code),
            'data' => $data
        );
    }

    /**
     * WP-Cron Trigger Handler (Runs every 12 hours: twicedaily)
     */
    public function handle_cron_sync() {
        $enable_cron = get_option('sbom_weather_enable_cron', true);
        if (!$enable_cron) {
            return;
        }
        $this->execute_sync(false);
    }

    /**
     * AJAX handler for Manual Sync from settings page
     */
    public function ajax_manual_sync() {
        check_ajax_referer('sbom_weather_sync_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission.', 'sbom-weather-connector')));
        }

        $force_refresh = !empty($_POST['force_refresh']) && $_POST['force_refresh'] === '1';
        $result = $this->execute_sync($force_refresh);
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    /**
     * Register REST API Endpoints (Optional Pull format)
     */
    public function register_rest_routes() {
        register_rest_route('sbom-weather/v1', '/manifest', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_manifest'),
            'permission_callback' => array($this, 'verify_rest_permission'),
        ));
    }

    /**
     * Verify REST permission via token
     */
    public function verify_rest_permission($request) {
        $configured_token = get_option('sbom_weather_endpoint_token', '');

        if (empty($configured_token)) {
            return current_user_can('manage_options');
        }

        $token_header = $request->get_header('x_sbom_weather_token');
        if (empty($token_header)) {
            $auth_header = $request->get_header('authorization');
            if ($auth_header && preg_match('/Bearer\s+(\S+)/i', $auth_header, $matches)) {
                $token_header = $matches[1];
            }
        }

        if (empty($token_header)) {
            $token_header = $request->get_param('token');
        }

        if (!empty($token_header) && hash_equals($configured_token, $token_header)) {
            return true;
        }

        return new WP_Error(
            'rest_forbidden',
            __('Valid auth token (X-SBOM-Weather-Token or Bearer) is required.', 'sbom-weather-connector'),
            array('status' => 403)
        );
    }

    /**
     * REST API callback: return collected manifest JSON
     */
    public function rest_get_manifest($request) {
        $manifest = $this->collect_manifest();
        return rest_ensure_response($manifest);
    }

    /**
     * Render settings page in WordPress Admin
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $endpoint_token = get_option('sbom_weather_endpoint_token', '');
        if (empty($endpoint_token)) {
            $endpoint_token = wp_generate_password(32, false);
            update_option('sbom_weather_endpoint_token', $endpoint_token);
        }

        $api_url = $this->get_effective_api_url();
        $api_token = get_option('sbom_weather_api_token', '');
        $site_id = $this->get_effective_site_id();
        $enable_cron = get_option('sbom_weather_enable_cron', true);
        $enable_pull = get_option('sbom_weather_enable_pull', false);
        $last_sync = get_option('sbom_weather_last_sync_result', null);

        $rest_endpoint_url = get_rest_url(null, 'sbom-weather/v1/manifest');
        ?>
        <div class="wrap">
            <h1>🌤️ <?php esc_html_e('SBOM Weather Connector Settings', 'sbom-weather-connector'); ?></h1>
            <p><?php esc_html_e('Collects WordPress core, plugin, and theme configuration data and syncs with the SBOM Weather security API.', 'sbom-weather-connector'); ?></p>

            <h2 class="nav-tab-wrapper">
                <a href="#tab-push" class="nav-tab nav-tab-active" onclick="switchTab(event, 'tab-push')"><?php esc_html_e('1. Auto Sync (Push / Cron)', 'sbom-weather-connector'); ?></a>
                <a href="#tab-pull" class="nav-tab" onclick="switchTab(event, 'tab-pull')"><?php esc_html_e('2. Endpoint (Pull / REST)', 'sbom-weather-connector'); ?></a>
                <a href="#tab-status" class="nav-tab" onclick="switchTab(event, 'tab-status')"><?php esc_html_e('3. Diagnostic Log', 'sbom-weather-connector'); ?></a>
            </h2>

            <!-- TAB 1: PUSH / CRON -->
            <div id="tab-push" class="sbom-tab-content" style="margin-top: 20px;">
                <form method="post" action="options.php">
                    <?php settings_fields('sbom_weather_settings_group'); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="sbom_weather_site_id"><?php esc_html_e('Site ID', 'sbom-weather-connector'); ?></label></th>
                            <td>
                                <input name="sbom_weather_site_id" type="text" id="sbom_weather_site_id" value="<?php echo esc_attr($site_id); ?>" class="regular-text" placeholder="例: site_corp_wordpress" />
                                <p class="description"><?php esc_html_e('Enter the target site ID issued in the SBOM Weather console.', 'sbom-weather-connector'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sbom_weather_api_token"><?php esc_html_e('API Token', 'sbom-weather-connector'); ?></label></th>
                            <td>
                                <input name="sbom_weather_api_token" type="password" id="sbom_weather_api_token" value="<?php echo esc_attr($api_token); ?>" class="regular-text" placeholder="sbw_live_xxxxxxxx" />
                                <p class="description"><?php esc_html_e('Enter the API key issued in the SBOM Weather console.', 'sbom-weather-connector'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sbom_weather_api_url"><?php esc_html_e('Destination API Endpoint', 'sbom-weather-connector'); ?></label></th>
                            <td>
                                <select id="sbom_weather_preset_url" style="margin-bottom: 8px; width: 100%; max-width: 580px;">
                                    <option value=""><?php esc_html_e('-- Select Preset or Custom --', 'sbom-weather-connector'); ?></option>
                                    <option value="http://localhost:8787/api/v1/sync">http://localhost:8787/api/v1/sync  (Local dev)</option>
                                    <option value="https://sbom-weather-backend.mahorobalab.workers.dev/api/v1/sync">https://sbom-weather-backend.mahorobalab.workers.dev  (Cloudflare dev)</option>
                                    <option value="https://api.sbom-weather.com/api/v1/sync">https://api.sbom-weather.com/api/v1/sync  (Production)</option>
                                </select>
                                <br />
                                <input name="sbom_weather_api_url" type="url" id="sbom_weather_api_url" value="<?php echo esc_attr($api_url); ?>" class="large-text" placeholder="https://..." />
                                <p class="description"><?php esc_html_e('Choose a preset from the dropdown above to auto-fill the URL, or enter any custom API endpoint URL.', 'sbom-weather-connector'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('WP-Cron Automatic Scheduled Sync', 'sbom-weather-connector'); ?></th>
                            <td>
                                <label for="sbom_weather_enable_cron">
                                    <input name="sbom_weather_enable_cron" type="checkbox" id="sbom_weather_enable_cron" value="1" <?php checked(1, $enable_cron); ?> />
                                    <?php esc_html_e('Automatically check hash & sync every 12 hours (twicedaily)', 'sbom-weather-connector'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Optional: Allow Cloudflare Pull', 'sbom-weather-connector'); ?></th>
                            <td>
                                <label for="sbom_weather_enable_pull">
                                    <input name="sbom_weather_enable_pull" type="checkbox" id="sbom_weather_enable_pull" value="1" <?php checked(1, $enable_pull); ?> />
                                    <?php esc_html_e('Register REST endpoint URL so Cloudflare can optionally pull manifest updates', 'sbom-weather-connector'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(__('Save Settings', 'sbom-weather-connector')); ?>
                </form>

                <hr style="margin: 30px 0 20px 0;" />
                <h3><?php esc_html_e('Manual Sync Test', 'sbom-weather-connector'); ?></h3>
                <p><?php esc_html_e('Collects the configuration right now with current settings, sends it to the API, and fetches diagnostic results.', 'sbom-weather-connector'); ?></p>
                <p style="margin-bottom: 12px;">
                    <label>
                        <input type="checkbox" id="chk-sbom-force-refresh" value="1" />
                        <?php esc_html_e('Force full manifest upload & bypass cache (Force Refresh)', 'sbom-weather-connector'); ?>
                    </label>
                </p>
                <button type="button" id="btn-sbom-manual-sync" class="button button-primary button-hero">
                    🚀 <?php esc_html_e('Sync Now & Check Weather', 'sbom-weather-connector'); ?>
                </button>
                <span id="sync-spinner" class="spinner" style="float: none; margin-top: 10px;"></span>
                <div id="sync-result-box" style="margin-top: 15px; display: none;"></div>
            </div>

            <!-- TAB 2: PULL / REST ENDPOINT (OPTIONAL) -->
            <div id="tab-pull" class="sbom-tab-content" style="margin-top: 20px; display: none;">
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Public REST Endpoint', 'sbom-weather-connector'); ?></th>
                        <td>
                            <code><?php echo esc_html($rest_endpoint_url); ?></code>
                            <p class="description"><?php esc_html_e('Allows fetching the manifest JSON via HTTP GET request.', 'sbom-weather-connector'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Endpoint Auth Token', 'sbom-weather-connector'); ?></th>
                        <td>
                            <input type="text" id="sbom_weather_endpoint_token" name="sbom_weather_endpoint_token" value="<?php echo esc_attr($endpoint_token); ?>" class="large-text" readonly style="background: #f0f0f1; font-family: monospace;" />
                            <p class="description"><?php esc_html_e('When sending requests, provide the token via one of the following:', 'sbom-weather-connector'); ?></p>
                            <ul style="list-style: disc; margin-left: 20px;">
                                <li>HTTP Header: <code>X-SBOM-Weather-Token: <?php echo esc_html($endpoint_token); ?></code></li>
                                <li>Authorization Header: <code>Authorization: Bearer <?php echo esc_html($endpoint_token); ?></code></li>
                                <li>Query Parameter: <code>?token=<?php echo esc_html($endpoint_token); ?></code></li>
                            </ul>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('curl Example', 'sbom-weather-connector'); ?></th>
                        <td>
                            <pre style="background: #1e1e1e; color: #fff; padding: 12px; border-radius: 6px; overflow-x: auto;"><code>curl -H "X-SBOM-Weather-Token: <?php echo esc_html($endpoint_token); ?>" "<?php echo esc_html($rest_endpoint_url); ?>"</code></pre>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- TAB 3: STATUS -->
            <div id="tab-status" class="sbom-tab-content" style="margin-top: 20px; display: none;">
                <h3><?php esc_html_e('Recent Sync Logs & Diagnostics', 'sbom-weather-connector'); ?></h3>
                <?php if ($last_sync): ?>
                    <table class="widefat striped">
                        <tbody>
                            <tr>
                                <th style="width: 220px;"><?php esc_html_e('Last Run Time', 'sbom-weather-connector'); ?></th>
                                <td><?php echo esc_html($last_sync['time']); ?></td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Sync Mode', 'sbom-weather-connector'); ?></th>
                                <td><code><?php echo esc_html(isset($last_sync['sync_mode']) ? $last_sync['sync_mode'] : 'POST'); ?></code></td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Manifest SHA-256 Hash', 'sbom-weather-connector'); ?></th>
                                <td><code><?php echo esc_html(isset($last_sync['manifest_hash']) ? $last_sync['manifest_hash'] : '-'); ?></code></td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Status Code', 'sbom-weather-connector'); ?></th>
                                <td><code><?php echo esc_html($last_sync['status_code']); ?></code></td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Security Weather', 'sbom-weather-connector'); ?></th>
                                <td>
                                    <?php 
                                    $w = $last_sync['weather'];
                                    $pressure = isset($last_sync['pressure_hpa']) ? (int) $last_sync['pressure_hpa'] : 1013;
                                    $days = isset($last_sync['days_neglected']) ? (int) $last_sync['days_neglected'] : 0;
                                    $w_label = __('Sunny (Safe)', 'sbom-weather-connector');
                                    $w_icon = '☀️';
                                    if ($w === 'typhoon') {
                                        $w_label = __('Typhoon (Neglected 7+ Days - Emergency!)', 'sbom-weather-connector');
                                        $w_icon = '🌀';
                                    } elseif ($w === 'thunderstorm') {
                                        $w_label = __('Thunderstorm (Critical Patch Required)', 'sbom-weather-connector');
                                        $w_icon = '⛈️';
                                    } elseif ($w === 'rain') {
                                        $w_label = __('Rain (Warning)', 'sbom-weather-connector');
                                        $w_icon = '🌧️';
                                    } elseif ($w === 'cloudy') {
                                        $w_label = __('Cloudy', 'sbom-weather-connector');
                                        $w_icon = '☁️';
                                    }
                                    echo esc_html($w_icon . ' ' . $w_label . ' (' . $w . ' / ' . $pressure . ' hPa / ' . $days . 'd)');
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Detected Alerts', 'sbom-weather-connector'); ?></th>
                                <td>
                                    <strong><?php echo esc_html($last_sync['alerts_count']); ?></strong>
                                    <?php if (isset($last_sync['active_vuln_count']) || isset($last_sync['inactive_vuln_count'])): ?>
                                        (Active: <?php echo esc_html((int)$last_sync['active_vuln_count']); ?> / Inactive: <?php echo esc_html((int)$last_sync['inactive_vuln_count']); ?>)
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th><?php esc_html_e('Inspected Components', 'sbom-weather-connector'); ?></th>
                                <td><?php echo esc_html($last_sync['packages_count']); ?> (Core + PHP + Active/Inactive Plugins + Themes)</td>
                            </tr>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p><?php esc_html_e('No sync logs yet. Please click \'Sync Now\'.', 'sbom-weather-connector'); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <script>
        // Preset Endpoint Selector sync
        (function() {
            var presetSelect = document.getElementById('sbom_weather_preset_url');
            var urlInput = document.getElementById('sbom_weather_api_url');
            if (!presetSelect || !urlInput) return;

            function syncPresetSelection() {
                var current = (urlInput.value || '').trim().replace(/\/+$/, '');
                var matched = false;
                for (var i = 0; i < presetSelect.options.length; i++) {
                    var optVal = (presetSelect.options[i].value || '').trim().replace(/\/+$/, '');
                    if (optVal && (optVal === current || optVal === current + '/api/v1/sync' || optVal.replace(/\/api\/v1\/sync$/, '') === current)) {
                        presetSelect.selectedIndex = i;
                        matched = true;
                        break;
                    }
                }
                if (!matched) {
                    presetSelect.selectedIndex = 0;
                }
            }

            syncPresetSelection();

            presetSelect.addEventListener('change', function() {
                if (this.value) {
                    urlInput.value = this.value;
                }
            });

            urlInput.addEventListener('input', syncPresetSelection);
        })();

        function switchTab(evt, tabId) {
            evt.preventDefault();
            document.querySelectorAll('.nav-tab').forEach(function(el) { el.classList.remove('nav-tab-active'); });
            document.querySelectorAll('.sbom-tab-content').forEach(function(el) { el.style.display = 'none'; });
            evt.currentTarget.classList.add('nav-tab-active');
            document.getElementById(tabId).style.display = 'block';
        }

        document.getElementById('btn-sbom-manual-sync').addEventListener('click', function() {
            var btn = this;
            var spinner = document.getElementById('sync-spinner');
            var resultBox = document.getElementById('sync-result-box');
            var forceChk = document.getElementById('chk-sbom-force-refresh');

            btn.disabled = true;
            spinner.classList.add('is-active');
            resultBox.style.display = 'none';

            var formData = new FormData();
            formData.append('action', 'sbom_weather_manual_sync');
            formData.append('nonce', '<?php echo wp_create_nonce("sbom_weather_sync_nonce"); ?>');
            formData.append('force_refresh', (forceChk && forceChk.checked) ? '1' : '0');

            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(function(res) { return res.json(); })
            .then(function(res) {
                btn.disabled = false;
                spinner.classList.remove('is-active');
                resultBox.style.display = 'block';

                if (res.success) {
                    var data = res.data.data;
                    var weatherEmoji = '☀️';
                    if (data.weather === 'typhoon') weatherEmoji = '🌀';
                    else if (data.weather === 'thunderstorm') weatherEmoji = '⛈️';
                    else if (data.weather === 'rain') weatherEmoji = '🌧️';
                    else if (data.weather === 'cloudy') weatherEmoji = '☁️';

                    resultBox.innerHTML = '<div class="notice notice-success inline" style="padding: 12px;">' +
                        '<p><strong>✅ ' + res.data.message + '</strong></p>' +
                        '<p>' + weatherEmoji + ' <strong>' + (data.weather || 'sunny') + '</strong> (' + (data.pressure_hpa || 1013) + ' hPa) | ' +
                        'Mode: <code>' + (data.sync_mode || 'POST') + '</code> | ' +
                        'Components: ' + (data.packages_count || 0) + ' | ' +
                        'Alerts: <strong>' + (data.alerts_count || 0) + '</strong></p>' +
                        '</div>';
                } else {
                    resultBox.innerHTML = '<div class="notice notice-error inline" style="padding: 12px;">' +
                        '<p><strong>❌ ' + (res.data ? res.data.message : 'Error') + '</strong></p>' +
                        '</div>';
                }
            })
            .catch(function(err) {
                btn.disabled = false;
                spinner.classList.remove('is-active');
                resultBox.style.display = 'block';
                resultBox.innerHTML = '<div class="notice notice-error inline" style="padding: 12px;">' +
                    '<p><strong>❌ Error:</strong> ' + err.message + '</p>' +
                    '</div>';
            });
        });
        </script>
        <?php
    }
}

// Initialize the plugin singleton
add_action('plugins_loaded', array('SBOM_Weather_Connector', 'get_instance'));
