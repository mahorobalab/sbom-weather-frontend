# SBOM Weather Connector (WordPress Plugin)

WordPress のコア・プラグイン・テーマ構成情報を収集し、セキュリティお天気（SBOM Weather）API と連携する超軽量コネクタープラグインです。

## 特徴
1. **Push形式 (自動定期同期)**:
   - WP-Cron により1日1回自動で最新の構成情報を収集・送信。
   - 管理画面から「今すぐ同期」の手動実行も可能。
2. **Pull形式 (セキュアなREST API)**:
   - `GET /wp-json/sbom-weather/v1/manifest`
   - トークン認証 (`X-SBOM-Weather-Token` または Bearer) により外部・当サービスから安全にオンデマンド取得可能。
3. **安全・軽量設計**:
   - 外部ライブラリへの依存なし。
   - データベースへの過度な書き込みを行わず、WordPress標準の Options API と Transients のみを使用。

